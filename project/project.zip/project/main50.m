clc;
clear;
close all;
warning('off','all');
%% Get input image
[f,p] = uigetfile('database1\*.tiff');
[~,filename] = fileparts(f);
% read input image
I1 = imread([p,f]);
% I1 = imcrop(I);
figure,imshow(I1);
title('Input High Resolution Image');

% run('vlfeat-0.9.20\toolbox\vl_root.m');
% run('vlfeat-0.9.20\toolbox\vl_setup.m');
%% i) Self Organising MAP based clustering
% converting to LAB color space
cform = makecform('srgb2lab');
lab_he = applycform(I1,cform);
ab = double(lab_he(:,:,2:3));
nrows = size(ab,1);
ncols = size(ab,2);
% Reshape
ab = reshape(ab,nrows*ncols,2);
ab = ab';
x = ab;
net = selforgmap([2 2]);
net = train(net,x);
view(net)
y = net(x);
classes = vec2ind(y);
pixel_labels1 = reshape(classes,512,512);

figure,
imshow(pixel_labels1,[]), title('image labeled by cluster index');

segmented_images = cell(1,4);
rgb_label = repmat(pixel_labels1,[1 1 3]);